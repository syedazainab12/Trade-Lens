import React, { useEffect, useState } from "react";
import { ethers } from "ethers";
import { contractABI, contractAddress } from "../utils/constants";
export const TransactionContext = React.createContext();
const { ethereum } = window;

const getEthereumContract = () => {
    const provider = new ethers.providers.Web3Provider(ethereum);
    const signer = provider.getSigner();
    return new ethers.Contract(contractAddress, contractABI, signer);
}

export const TransactionProvider = ({ children }) => {
    const [currentAccount, setCurrentAccount] = useState("");
    const [ids, setIds] = useState([]);
    const [manufacturer, setManufacturerFormData] = useState({});
    const [shippingCompany, setShippingCompany] = useState({});
    const [receiver, setReceiver] = useState({});
    
    const [manufacturerFormData, setManufacturerFormDataFormData] = useState({
        m_itemID: "",
        m_itemDescription: "",
        m_itemCondition: "",
        m_shippedOn: "",
    });
    const [shippingCompanyFormData, setShippingCompanyFormData] = useState({
        sc_name: "",
        sc_itemID: "",
        sc_itemCondition: "",
        sc_receivedOn: "",
        sc_shippedOn: "",
    });
    const [receiverFormData, setReceiverFormData] = useState({
        r_itemID: "",
        r_itemCondition: "",
        r_receivedOn: "",
    });

    const handleManufacturerFormData = (e) => {
        setManufacturerFormDataFormData({
            ...manufacturerFormData,
            [e.target.name]: e.target.value,
        });

    };
    const handleShippingCompanyFormData = (e) => {
        setShippingCompanyFormData({
            ...shippingCompanyFormData,
            [e.target.name]: e.target.value,
        });
    };
    const handleReceiverFormData = (e) => {
        setReceiverFormData({
            ...receiverFormData,
            [e.target.name]: e.target.value,
        });
    };

    const checkIfWalletIsConnect = async () => {
        try {
            if (!ethereum) return alert("Please install MetaMask.");

            const accounts = await ethereum.request({ method: "eth_accounts" });
            if (accounts.length) {
                setCurrentAccount(accounts[0]);

            } else {
                console.log("No accounts found");
            }
        } catch (error) {
            console.log(error);
        }
    };
    const connectWallet = async () => {
        try {
            if (!ethereum) return alert("Please install MetaMask.");

            const accounts = await ethereum.request({
                method: "eth_requestAccounts",
            });

            setCurrentAccount(accounts[0]);
            window.location.reload();
        } catch (error) {
            console.log(error);

            throw new Error("No ethereum object");
        }
    };
    const addManufacturer = async () => {
        try {
            const contract = getEthereumContract();
            const transaction = await contract.addManufacturer(
                manufacturerFormData.m_itemID,
                manufacturerFormData.m_itemDescription,
                manufacturerFormData.m_itemCondition,
                manufacturerFormData.m_shippedOn,
            );
            await transaction.wait();
            console.log(`${manufacturerFormData.m_itemID} added`);
            setManufacturerFormDataFormData({
                m_itemID: "",
                m_itemDescription: "",
                m_itemCondition: "",
                m_shippedOn: "",
            });

        } catch (error) {
            console.log(error);
        }
    };
    const addShippingCompany = async () => {
        try {
            const contract = getEthereumContract();
            const transaction = await contract.addShippingCompany(
                shippingCompanyFormData.sc_name,
                shippingCompanyFormData.sc_itemID,
                shippingCompanyFormData.sc_itemCondition,
                shippingCompanyFormData.sc_receivedOn,
                shippingCompanyFormData.sc_shippedOn,

            );
            await transaction.wait();
            console.log(`${shippingCompanyFormData.sc_itemID} added`);
            setShippingCompanyFormData({
                sc_name: "",
                sc_itemID: "",
                sc_itemCondition: "",
                sc_receivedOn: "",
                sc_shippedOn: "",
            });

        } catch (error) {
            console.log(error);
        }
    };
    const addReceiver = async () => {
        try {
            const contract = getEthereumContract();
            const transaction = await contract.addReceiver(
                receiverFormData.r_itemID,
                receiverFormData.r_itemCondition,
                receiverFormData.r_receivedOn,
            );
            await transaction.wait();
            console.log(`${receiverFormData.r_itemID} added`);
            setReceiverFormData({
                r_itemID: "",
                r_itemCondition: "",
                r_receivedOn: "",
            });

        } catch (error) {
            console.log(error);
        }
    };
    
    
    const sendTransactions = async () => {
        addManufacturer();
        addShippingCompany();
        addReceiver();
    }

    const getIds = async () => {
        const transactionContract = getEthereumContract()
        const allIds = await transactionContract.getIDs();
        //convert to number
        let temp = Number(allIds["_hex"])
        console.log("temp = " , temp);
        // array from 0 to temp
        let arr = Array.from({ length: temp }, (_, i) => i);
        console.log("IDS: " , arr);
        setIds(arr);
    }


    const getById = async (id) => {
        const transactionContract = getEthereumContract()
        const data = await transactionContract.getByID(id);
        setManufacturerFormData(data[0]);
        setShippingCompany(data[1]);
        setReceiver(data[2]);
    }

    useEffect(() => {
        checkIfWalletIsConnect();
    }, []);
    return (
        <TransactionContext.Provider
            value={{
                currentAccount,
                connectWallet,
                manufacturerFormData,
                handleManufacturerFormData,
                shippingCompanyFormData,
                handleShippingCompanyFormData,
                sendTransactions,
                ids,
                getIds,
                getById,
                manufacturer,
                shippingCompany,
                receiverFormData,
                handleReceiverFormData,
                receiver
            }}
        >
            {children}
        </TransactionContext.Provider>
    );
}
