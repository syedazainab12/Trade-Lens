import React, { useEffect, useState, useContext } from "react";
import { BrowserRouter as Router, Route, Routes, Link } from "react-router-dom";
import './App.css';
import Connect from './components/Connect';
import Dashboard from './components/Dashboard';
import Txns from "./components/Txns";
import View from "./components/View";
import Search from "./components/Search";
import { TransactionContext } from "./context/TransactionContext";

function App() {
  const { currentAccount } =
    useContext(TransactionContext);
  return (
    <Router>
      <Routes>
        {
          currentAccount ? <Route path="/" element={<Dashboard />} /> : <Route path="/" element={<Connect />} />
        }
        <Route path="/txns" element={<Txns />} />
        <Route path="/view" element={<View />} />
        <Route path="/search" element={<Search />} />
      </Routes>
    </Router>);
}

export default App;
