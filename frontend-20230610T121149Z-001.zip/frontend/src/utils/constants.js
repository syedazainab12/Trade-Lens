import abi from './TradeLens.json'

export const contractABI = abi.abi;
export const contractAddress = "0x461c818bE88a84E139cf8aFfbc57138343dD351E";