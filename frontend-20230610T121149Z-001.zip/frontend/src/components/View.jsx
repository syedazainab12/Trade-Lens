import React, { useState, SyntheticEvent, useContext, useEffect } from 'react'
import Tabs from '@mui/material/Tabs';
import Tab from '@mui/material/Tab';
import EmployeeDetails from './cards/Manufacturer'
import ShippingCompany from './cards/ShippingCompany';
import { TransactionContext } from '../context/TransactionContext';
import { useLocation } from 'react-router-dom';
import Receiver from './cards/Receiver';
import Manufacturer from './cards/Manufacturer';

const View = () => {
    const locationS = useLocation();
    const selectedId = locationS.state.id;
    const [value, setValue] = useState('Item details');
    const { getIds,
        ids,
        getById,
        manufacturer,
        shippingCompany,
        receiver
    } = useContext(TransactionContext);

    const handleChange = (event: SyntheticEvent, newValue: string) => {
        setValue(newValue);
    };
    useEffect(() => {
        getById(selectedId);
    }, []);

    return (
        <div className='container' >
            <div className='dashboard-container'>
                <Tabs
                    value={value}
                    onChange={handleChange}
                    textColor="primary"
                    indicatorColor="primary"
                    aria-label="secondary tabs example"
                >
                    <Tab value="Manufacturer" label="Manufacturer" />
                    <Tab value="Shipping Company" label="Shipping Company" />
                    <Tab value="Receiver" label="Receiver" />

                </Tabs>
                <div className='view-container'>
                    {value === 'Manufacturer' &&

                        <Manufacturer details={manufacturer} />

                    }

                    {
                        value === 'Shipping Company' &&
                        <ShippingCompany sc={shippingCompany} />
                    }

                    {
                        value === 'Receiver' && 
                        <Receiver rec={receiver} />
                    }

                </div>
            </div>
        </div >
    )
}

export default View