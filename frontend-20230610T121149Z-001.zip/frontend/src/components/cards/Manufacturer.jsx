import React from 'react'
import Card from '@mui/material/Card';
import CardContent from '@mui/material/CardContent';
import Typography from '@mui/material/Typography';
const Manufacturer = ({ details }) => {
    return (
        <div className='view-container'>
        <div className="view-item">
            <Card sx={{ maxWidth: 275, }}>
                <CardContent>
                    <Typography sx={{ fontSize: 14 }} color="text.primary" gutterBottom>
                        Item ID: {details.m_itemID}
                    </Typography>
                    <Typography variant="body2">
                        Item Description: {details.m_itemDescription}
                    </Typography>
                    <Typography variant="body2">
                        Item Condition: {details.m_itemCondition}
                    </Typography>
                    <Typography variant="body2">
                        Shipped On: {details.m_shippedOn}
                    </Typography>
                </CardContent>

            </Card>
        </div>
    </div>
    )
}

export default Manufacturer