import React, { useState, useEffect } from 'react'
import Card from '@mui/material/Card';
import CardContent from '@mui/material/CardContent';
import Typography from '@mui/material/Typography';
const ShippingCompany = ({ sc }) => {
   
    return (
        <div className='view-container'>
        <div className="view-item">
            <Card sx={{ maxWidth: 275, }}>
                <CardContent>
                    <Typography sx={{ fontSize: 14 }} color="text.primary" gutterBottom>
                        Shipping Company Name: {sc.sc_name}
                    </Typography>
                    <Typography sx={{ fontSize: 14 }} color="text.primary" gutterBottom>
                        Item ID: {sc.sc_itemID}
                    </Typography>
                    <Typography variant="body2">
                        Item Condition: {sc.sc_itemCondition}
                    </Typography>
                    <Typography variant="body2">
                        Received On: {sc.sc_receivedOn}
                    </Typography>
                    <Typography variant="body2">
                        Shipped On: {sc.sc_shippedOn}
                    </Typography>
                </CardContent>

            </Card>
        </div>
    </div>
    )
}

export default ShippingCompany