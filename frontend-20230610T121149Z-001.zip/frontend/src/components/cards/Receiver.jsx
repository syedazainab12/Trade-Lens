import React from 'react'
import Card from '@mui/material/Card';
import CardContent from '@mui/material/CardContent';
import Typography from '@mui/material/Typography';
const Receiver = ({ rec }) => {
    return (
        <div className='view-container'>
        <div className="view-item">
            <Card sx={{ maxWidth: 275, }}>
                <CardContent>
                    <Typography sx={{ fontSize: 14 }} color="text.primary" gutterBottom>
                        Item ID: {rec.r_itemID}
                    </Typography>
                    <Typography variant="body2">
                        Item Condition: {rec.r_itemCondition}
                    </Typography>
                    <Typography variant="body2">
                        Received On: {rec.r_receivedOn}
                    </Typography>
                </CardContent>

            </Card>
        </div>
    </div>
    )
}

export default Receiver