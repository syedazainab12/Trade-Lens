import React, { useState, SyntheticEvent, useContext } from 'react'
import Tabs from '@mui/material/Tabs';
import Tab from '@mui/material/Tab';
import TextField from '@mui/material/TextField';
import Box from '@mui/material/Box';
import Button from '@mui/material/Button';
import { useNavigate } from "react-router-dom";

import { TransactionContext } from '../context/TransactionContext';

const Dashboard = () => {
    const [value, setValue] = useState('Manufacturer');
    // const [countArrayRoles, setcountArrayRoles] = useState([0]);
    // const [countArrayBenefits, setcountArrayBenefits] = useState([0]);
    const navigate = useNavigate();
    const {
        manufacturerFormData,
        handleManufacturerFormData,

        shippingCompanyFormData,
        handleShippingCompanyFormData,

        receiverFormData,
        handleReceiverFormData,

        sendTransactions

    }
        = useContext(TransactionContext);
    const handleChange = (event: SyntheticEvent, newValue: string) => {
        setValue(newValue);
    };
    
    const handleSubmit = () => {
        const { m_itemID, m_itemDescription, m_itemCondition } = manufacturerFormData;
        // const { sc_name, sc_itemID, sc_itemCondition, sc_receivedOn, sc_shippedOn } = shippingCompanyFormData;


        if (m_itemID != "" && m_itemDescription != "" && m_itemCondition != "") {
            console.log("SENDING TXNS!!")
            sendTransactions()
        }
        else {
            alert("Please fill all the fields")
        }
    }
    return (
        <div className='container'>
            <div className='dashboard-container'>
                <Tabs
                    value={value}
                    onChange={handleChange}
                    textColor="primary"
                    indicatorColor="primary"
                    aria-label="secondary tabs example"
                >
                    <Tab value="Manufacturer" label="Manufacturer" />
                    <Tab value="Shipping Company" label="Shipping Company" />
                    <Tab value="Receiver" label="Receiver" />
                    
                </Tabs>
                <div className={'input-container'}>

                    <Box
                        component="form"
                        sx={{
                            '& .MuiTextField-root': {
                                m: 1, width: '25ch', marginTop: '15px',
                            },
                        }}
                        noValidate
                        autoComplete="off"
                    >
                        {
                            value === 'Manufacturer' ? (
                                <div>
                                    <TextField
                                        required
                                        id="outlined-required"
                                        label="Item ID (Manufacturer)"
                                        name="m_itemID"
                                        value={manufacturerFormData.m_itemID}
                                        // onChange={handleManufacturerFormData}
                                        onChange={(e) => handleManufacturerFormData(e)}

                                    />
                                    <TextField
                                        required
                                        id="outlined-required"
                                        label="Item Description (Manufacturer)"
                                        name="m_itemDescription"
                                        value={manufacturerFormData.m_itemDescription}
                                        // onChange={handleManufacturerFormData}
                                        onChange={(e) => handleManufacturerFormData(e)}

                                    />
                                    <TextField
                                        required
                                        id="outlined-required"
                                        label="Item Condition (Manufacturer)"
                                        name="m_itemCondition"
                                        value={manufacturerFormData.m_itemCondition}
                                        onChange={(e) => handleManufacturerFormData(e)}
                                    />

                                    <TextField
                                        required
                                        id="outlined-required"
                                        label="Shipped On (Manufacturer)"
                                        name="m_shippedOn"
                                        value={manufacturerFormData.m_shippedOn}
                                        onChange={(e) => handleManufacturerFormData(e)}
                                    />


                                    <div className='submit-button'>
                                        <Button variant="contained" onClick={() => { setValue("Shipping Company") }}>Next</Button>
                                    </div>
                                </div>

                            ) : value === 'Shipping Company' ? (
                                <div>
                                    <TextField
                                        required
                                        id="outlined-required"
                                        label="Shipping Company Name"
                                        name="sc_name"
                                        value={shippingCompanyFormData.sc_name}
                                        onChange={(e) => handleShippingCompanyFormData(e)}

                                    />
                                    <TextField
                                        required
                                        id="outlined-required"
                                        label="Item ID (Shipping Company)"
                                        name="sc_itemID"
                                        value={shippingCompanyFormData.sc_itemID}
                                        onChange={(e) => handleShippingCompanyFormData(e)}

                                    />
                                    <TextField
                                        required
                                        id="outlined-required"
                                        label="Item Condition (Shipping Company)"
                                        name="sc_itemCondition"
                                        value={shippingCompanyFormData.sc_itemCondition}
                                        onChange={(e) => handleShippingCompanyFormData(e)}

                                    />
                                    <TextField
                                        required
                                        id="outlined-required"
                                        label="Received On (Shipping Company)"
                                        name="sc_receivedOn"
                                        value={shippingCompanyFormData.sc_receivedOn}
                                        onChange={(e) => handleShippingCompanyFormData(e)}
                                    />

                                    <TextField
                                        required
                                        id="outlined-required"
                                        label="Shipped On (Shipping Company)"
                                        name="sc_shippedOn"
                                        value={shippingCompanyFormData.sc_shippedOn}
                                        onChange={(e) => handleShippingCompanyFormData(e)}
                                    />

                                    <div className='submit-button'>
                                        <Button variant="contained" onClick={() => { setValue("Receiver") }}>Next</Button>
                                    </div>


                                    {/* <div className='submit-button'>
                                        <Button variant="contained" onClick={() => { setValue("Employee salary") }}>Next</Button>
                                    </div> */}
                                    
                                </div> 
                            ) : value === 'Receiver' ? (
                                <div>
                                    <TextField
                                        required
                                        id="outlined-required"
                                        label="Item ID (Receiver)"
                                        name="r_itemID"
                                        value={receiverFormData.r_itemID}
                                        onChange={(e) => handleReceiverFormData(e)}

                                    />
                                    <TextField
                                        required
                                        id="outlined-required"
                                        label="Item Condition (Receiver)"
                                        name="r_itemCondition"
                                        value={receiverFormData.r_itemCondition}
                                        onChange={(e) => handleReceiverFormData(e)}

                                    />
                                    <TextField
                                        required
                                        id="outlined-required"
                                        label="Received On (Receiver)"
                                        name="r_receivedOn"
                                        value={receiverFormData.r_receivedOn}
                                        onChange={(e) => handleReceiverFormData(e)}
                                    />
                                    <div className='submit-button'>
                                        <Button variant="contained" onClick={handleSubmit} >Submit</Button>
                                    </div>
                                </div>
                            )
                            : null
                        }

                    </Box>

                </div>

                <div className='view-button'>
                    <Button variant="contained"
                        onClick={() => { navigate('/txns') }}
                    >View Transactions</Button>
                </div>
                <div className='view-button'>
                    <Button variant="contained"
                        onClick={() => { navigate('/search') }}
                    >Search</Button>
                </div>
            </div >

        </div >
    )
}

export default Dashboard