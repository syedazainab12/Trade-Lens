import React, { useState, useContext } from 'react'
import Button from '@mui/material/Button';
import { TransactionContext } from '../context/TransactionContext';


const Connect = () => {
    const { connectWallet } = useContext(TransactionContext);
    return (
        <div className='container'>
            <div className='connect-container'>
                <div className="connect-container-header">
                    <h1>Connect Wallet</h1>
                </div>
                <div className="connect-button">
                    <Button variant="contained" onClick={connectWallet}>Connect wallet</Button>
                </div>
            </div>
        </div>
    )
}

export default Connect